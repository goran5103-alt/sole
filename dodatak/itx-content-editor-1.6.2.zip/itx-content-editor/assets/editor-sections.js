/**
 * ITX Content Editor — sekcije
 * ---------------------------------------------------------------
 * Deli sadržaj strane na logičke sekcije (elemente prvog nivoa u
 * <main>) i dodaje im kontrole: pomeri gore/dole, obriši, dodaj novu.
 *
 * VAŽNO za ispravnost: svaka strukturna izmena primenjuje se ISTOVREMENO
 * na živi DOM i na netaknuti šablon, jer se izmene teksta mapiraju
 * putanjama kroz DOM — ako se stabla raziđu, putanje pokažu na pogrešan
 * element.
 *
 * VAŽNO za brzinu: sve ovo živi isključivo u adminu. Sačuvani sadržaj je
 * običan HTML koji stilizuje CSS teme — na sajtu koji posetilac vidi
 * plugin ne dodaje nijedan fajl.
 */
(function (global) {
	'use strict';
	if (!global.ItxEditor) return;

	var P = global.ItxEditor.prototype;

	var NOVA_SEKCIJA =
		'<section class="itx-blok">' +
			'<div class="container">' +
				'<div class="itx-blok-sadrzaj">' +
					'<h2>Naslov nove sekcije</h2>' +
					'<p>Ovde upišite tekst. Enter pravi novi pasus, a slike dodajete dugmetom „Slika“.</p>' +
				'</div>' +
			'</div>' +
		'</section>';

	/* ---------- pomoćno ---------- */

	function elFromHTML(doc, html) {
		var d = doc.createElement('div');
		d.innerHTML = html;
		return d.firstElementChild;
	}
	function plainPaste(doc) {
		return function (e) {
			e.preventDefault();
			var t = (e.clipboardData || doc.defaultView.clipboardData).getData('text/plain');
			doc.execCommand('insertText', false, t);
		};
	}

	P._liveSections = function () {
		var out = [];
		for (var c = this.live.firstElementChild; c; c = c.nextElementSibling) {
			if (!c.hasAttribute('data-itx-ui')) out.push(c);
		}
		return out;
	};
	P._tmplSections = function () {
		var out = [];
		for (var c = this.tmpl.firstElementChild; c; c = c.nextElementSibling) out.push(c);
		return out;
	};

	/* ---------- slobodan blok (tekst + slike, kao blog) ---------- */

	P.initFreeBlock = function (box) {
		var self = this;
		if (box.getAttribute('data-itx-free')) return;
		this.freeEls = this.freeEls || [];
		box.setAttribute('contenteditable', 'true');
		box.setAttribute('data-itx-free', 't');
		box.addEventListener('paste', plainPaste(this.doc));
		box.addEventListener('input', function () {
			if (self.freeEls.indexOf(box) === -1) self.freeEls.push(box);
			self._markDirty();
		});
		if (this.freeEls.indexOf(box) === -1) this.freeEls.push(box);
	};

	P.addImageToBlock = function (box) {
		var self = this;
		if (!this.onImageRequest) return;
		// prazan img samo kao nosilac zahteva; ubacuje se tek kad se izabere slika
		var nosilac = this.doc.createElement('img');
		this.onImageRequest(nosilac, function (url) {
			var fig = self.doc.createElement('figure');
			var img = self.doc.createElement('img');
			img.src = url;
			img.alt = '';
			fig.appendChild(img);
			box.appendChild(fig);
			if (self.freeEls.indexOf(box) === -1) self.freeEls.push(box);
			self._markDirty();
			self.refreshSections();
		});
	};

	/* ---------- strukturne operacije ---------- */

	P.moveSection = function (i, smer) {
		var L = this._liveSections(), T = this._tmplSections();
		var j = i + smer;
		if (j < 0 || j >= L.length || !T[i] || !T[j]) return;
		if (smer < 0) {
			L[i].parentNode.insertBefore(L[i], L[j]);
			T[i].parentNode.insertBefore(T[i], T[j]);
		} else {
			L[j].parentNode.insertBefore(L[j], L[i]);
			T[j].parentNode.insertBefore(T[j], T[i]);
		}
		this._markDirty();
		this.refreshSections();
	};

	P.deleteSection = function (i) {
		var L = this._liveSections(), T = this._tmplSections();
		if (!L[i] || !T[i]) return;
		var sek = L[i];
		// izbaci reference na izmene unutar obrisane sekcije
		this.dirtyEls = this.dirtyEls.filter(function (el) { return !sek.contains(el); });
		this.textSpans = this.textSpans.filter(function (r) { return !sek.contains(r.span); });
		if (this.freeEls) this.freeEls = this.freeEls.filter(function (b) { return !sek.contains(b); });
		L[i].parentNode.removeChild(L[i]);
		T[i].parentNode.removeChild(T[i]);
		this._markDirty();
		this.refreshSections();
	};

	// posleIdx = -1 znači "na sam početak"
	P.addSection = function (posleIdx) {
		var L = this._liveSections(), T = this._tmplSections();
		var lnode = elFromHTML(this.doc, NOVA_SEKCIJA);
		var tnode = elFromHTML(this.tmpl.ownerDocument, NOVA_SEKCIJA);
		if (posleIdx < 0) {
			// insertBefore prvog ELEMENTA (a ne na sam početak childNodes) —
			// tako vodeći beli znaci ostaju netaknuti i offset mapiranja važi
			this.live.insertBefore(lnode, L[0] || null);
			this.tmpl.insertBefore(tnode, T[0] || null);
		} else {
			this.live.insertBefore(lnode, L[posleIdx] ? L[posleIdx].nextElementSibling : null);
			this.tmpl.insertBefore(tnode, T[posleIdx] ? T[posleIdx].nextElementSibling : null);
		}
		this.initFreeBlock(lnode.querySelector('.itx-blok-sadrzaj'));
		this._markDirty();
		this.refreshSections();
		lnode.scrollIntoView({ behavior: 'smooth', block: 'center' });
	};


	/* ---------- kopiranje sekcije ---------- */

	// ID-jevi koje tema vezuje iz JS-a; kopija sa istim ID-em bila bi "mrtva",
	// a duplirano sidro (#usluge, #tim) pokvarilo bi linkove iz menija.
	function imaIdjeve(el) {
		return !!(el.id || el.querySelector('[id]'));
	}
	function skiniIdjeve(el) {
		el.removeAttribute('id');
		var svi = el.querySelectorAll('[id]');
		for (var i = 0; i < svi.length; i++) svi[i].removeAttribute('id');
	}

	P.duplicateSection = function (i) {
		var L = this._liveSections(), T = this._tmplSections();
		if (!L[i] || !T[i]) return;

		if (imaIdjeve(L[i])) {
			var poruka =
				'Ova sekcija ima ugrađenu funkcionalnost ili sidro (npr. slajder sa strelicama).\n\n' +
				'Kopija će biti VIZUELNA — izgledaće isto, ali strelice i slično neće raditi,\n' +
				'jer dve iste sekcije ne mogu da dele istu oznaku.\n\nNapraviti kopiju?';
			if (!this.doc.defaultView.confirm(poruka)) return;
		}

		var lkopija = L[i].cloneNode(true);
		var tkopija = T[i].cloneNode(true);
		skiniIdjeve(lkopija);
		skiniIdjeve(tkopija);

		// kopija ne sme da nosi zatečeno stanje uređivanja iz originala
		var tragovi = lkopija.querySelectorAll('[contenteditable],[data-itx-edit],[data-itx-free],[data-itx-tmp]');
		for (var k = 0; k < tragovi.length; k++) {
			tragovi[k].removeAttribute('contenteditable');
			tragovi[k].removeAttribute('data-itx-edit');
			tragovi[k].removeAttribute('data-itx-free');
		}

		L[i].parentNode.insertBefore(lkopija, L[i].nextElementSibling);
		T[i].parentNode.insertBefore(tkopija, T[i].nextElementSibling);

		this._scan(lkopija);          // tekst i slike u kopiji odmah postaju izmenjivi
		this._markDirty();
		this.refreshSections();
		lkopija.scrollIntoView({ behavior: 'smooth', block: 'center' });
	};


	/* ---------- STAVKE unutar sekcije (kartica, red cenovnika, stavka liste) ----------
	   Radi generički, bez ijedne klase specifične za konkretan sajt: stavka je
	   svaki element koji ima BAR JEDNOG BRATA istog tipa i istih klasa. Tako se
	   prepoznaju kartice, redovi tabele, stavke harmonike i sl. na bilo kojoj temi.
	   Kontrola se prikazuje samo za stavku pod mišem (najdublju), da ne zatrpa ekran. */

	// Potpis = tip elementa + PRVA (osnovna) klasa. Namerno se ignorišu ostale
	// klase, jer tema u toku rada dodaje klase stanja (is-open, is-visible,
	// reveal...) pa bi inače dve iste kartice imale različit potpis i stavke se
	// ne bi prepoznale.
	function potpis(el) {
		var k = (el.getAttribute('class') || '').trim().split(/\s+/)[0] || '';
		return el.tagName + '|' + k;
	}
	function jeStavka(el) {
		if (!el.parentElement) return false;
		if (el.hasAttribute('data-itx-tmp')) return false;   // privremeni span editora nije stavka
		var p = potpis(el), n = 0;
		for (var c = el.parentElement.firstElementChild; c; c = c.nextElementSibling) {
			if (c.hasAttribute('data-itx-tmp')) continue;
			if (potpis(c) === p) n++;
			if (n >= 2) return true;
		}
		return false;
	}

	P._stavkaZa = function (cilj) {
		var n = cilj;
		while (n && n !== this.live) {
			if (n.hasAttribute && n.hasAttribute('data-itx-ui')) return null;
			if (n.closest && n.closest('[data-itx-free]')) return null;   // slobodan blok se ionako slobodno uređuje
			if (n.closest && n.closest('[data-itx-slot]')) return null;   // slot popunjava tema
			if (n.parentElement && n.parentElement !== this.live && jeStavka(n)) {
				var r = n.getBoundingClientRect();
				if (r.height >= 28 && r.width >= 40) return n;
			}
			n = n.parentElement;
		}
		return null;
	};

	// klon bilo kog čvora (stavke) — istovremeno u živom DOM-u i u šablonu
	P.duplicateNode = function (live) {
		var path = this._elPath(live);
		var t = path && this._tmplByPath(path);
		if (!t) return;
		var lk = live.cloneNode(true), tk = t.cloneNode(true);
		skiniIdjeve(lk); skiniIdjeve(tk);
		var tragovi = lk.querySelectorAll('[contenteditable],[data-itx-edit],[data-itx-free],[data-itx-tmp]');
		for (var i = 0; i < tragovi.length; i++) {
			tragovi[i].removeAttribute('contenteditable');
			tragovi[i].removeAttribute('data-itx-edit');
			tragovi[i].removeAttribute('data-itx-free');
		}
		live.parentNode.insertBefore(lk, live.nextElementSibling);
		t.parentNode.insertBefore(tk, t.nextElementSibling);
		this._scan(lk);
		this._markDirty();
		this.refreshSections();
	};

	P.deleteNode = function (live) {
		var path = this._elPath(live);
		var t = path && this._tmplByPath(path);
		if (!t) return;
		this.dirtyEls = this.dirtyEls.filter(function (el) { return !live.contains(el); });
		this.textSpans = this.textSpans.filter(function (r) { return !live.contains(r.span); });
		if (this.freeEls) this.freeEls = this.freeEls.filter(function (b) { return !live.contains(b); });
		live.parentNode.removeChild(live);
		t.parentNode.removeChild(t);
		this._markDirty();
		this.refreshSections();
	};

	P._ukljuciStavke = function () {
		var self = this, d = this.doc;
		if (this._stavkeUkljucene) return;
		this._stavkeUkljucene = true;

		var cip = d.createElement('div');
		cip.className = 'itx-ui-stavka';
		cip.setAttribute('data-itx-ui', 't');
		cip.style.display = 'none';
		var bKopija = d.createElement('button');
		bKopija.type = 'button'; bKopija.textContent = '⧉'; bKopija.title = 'Napravi kopiju ove stavke';
		var bBrisi = d.createElement('button');
		bBrisi.type = 'button'; bBrisi.textContent = '✕'; bBrisi.title = 'Obriši ovu stavku'; bBrisi.className = 'itx-x';
		cip.appendChild(bKopija); cip.appendChild(bBrisi);
		this._sloj.parentNode.appendChild(cip);

		var trenutna = null;
		bKopija.addEventListener('click', function (e) {
			e.preventDefault(); e.stopPropagation();
			if (trenutna) { self.duplicateNode(trenutna); trenutna = null; cip.style.display = 'none'; }
		});
		bBrisi.addEventListener('click', function (e) {
			e.preventDefault(); e.stopPropagation();
			if (trenutna && d.defaultView.confirm('Obrisati ovu stavku?')) {
				self.deleteNode(trenutna); trenutna = null; cip.style.display = 'none';
			}
		});

		d.addEventListener('mouseover', function (e) {
			if (e.target.closest && e.target.closest('[data-itx-ui]')) return;
			var st = self._stavkaZa(e.target);
			if (!st) { return; }
			if (st === trenutna) return;
			trenutna = st;
			var r = st.getBoundingClientRect();
			cip.style.display = 'flex';
			cip.style.top = (r.top + d.defaultView.scrollY + 4) + 'px';
			cip.style.left = (r.left + d.defaultView.scrollX + r.width - 4) + 'px';
		});
	};

	/* ---------- kontrole preko sekcija ---------- */

	P.enableSections = function () {
		var d = this.doc;
		if (!d.getElementById('itx-ui-css')) {
			var st = d.createElement('style');
			st.id = 'itx-ui-css';
			st.setAttribute('data-itx-ui', 't');
			st.textContent =
				'.itx-ui-sloj{position:absolute;inset:0;pointer-events:none;z-index:99999}' +
				'.itx-ui-okvir{position:absolute;pointer-events:none;border:2px dashed rgba(108,140,39,.55);border-radius:6px;transition:border-color .2s}' +
				'.itx-ui-okvir:hover{border-color:rgba(108,140,39,.95)}' +
				'.itx-ui-alat{position:absolute;pointer-events:auto;display:flex;gap:4px;background:#fff;padding:4px;border-radius:8px;' +
					'box-shadow:0 4px 14px rgba(0,0,0,.18);font:600 12px/1 system-ui,sans-serif}' +
				'.itx-ui-alat button{border:none;cursor:pointer;background:#f1f3ee;color:#22301d;border-radius:5px;padding:6px 9px;font:inherit}' +
				'.itx-ui-alat button:hover{background:#6C8C27;color:#fff}' +
				'.itx-ui-alat button[disabled]{opacity:.35;cursor:default}' +
				'.itx-ui-alat button.itx-x:hover{background:#c0392b}' +
				'.itx-ui-plus{position:absolute;pointer-events:auto;transform:translateX(-50%);background:#6C8C27;color:#fff;border:none;' +
					'cursor:pointer;border-radius:20px;padding:6px 16px;font:600 12px/1 system-ui,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.2)}' +
				'.itx-ui-plus:hover{background:#22301d}' +
				'.itx-ui-stavka{position:absolute;z-index:100000;display:flex;gap:3px;transform:translateX(-100%);' +
					'background:#fff;padding:3px;border-radius:7px;box-shadow:0 3px 10px rgba(0,0,0,.22)}' +
				'.itx-ui-stavka button{border:none;cursor:pointer;background:#eef1e8;color:#22301d;border-radius:5px;' +
					'padding:4px 8px;font:600 12px/1 system-ui,sans-serif}' +
				'.itx-ui-stavka button:hover{background:#6C8C27;color:#fff}' +
				'.itx-ui-stavka button.itx-x:hover{background:#c0392b}';
			d.head.appendChild(st);
		}
		var sloj = d.getElementById('itx-ui-sloj');
		if (!sloj) {
			sloj = d.createElement('div');
			sloj.id = 'itx-ui-sloj';
			sloj.className = 'itx-ui-sloj';
			sloj.setAttribute('data-itx-ui', 't');
			d.body.appendChild(sloj);
		}
		this._sloj = sloj;
		var self = this;
		if (!this._resizeVezan) {
			this._resizeVezan = true;
			d.defaultView.addEventListener('resize', function () { self.refreshSections(); });
		}
		this._ukljuciStavke();
		this.refreshSections();
	};

	P.refreshSections = function () {
		if (!this._sloj) return;
		var self = this, d = this.doc, sloj = this._sloj;
		sloj.innerHTML = '';
		var L = this._liveSections();
		var sw = d.defaultView.scrollX, sy = d.defaultView.scrollY;

		function dugme(txt, naslov, klasa, fn, iskljuceno) {
			var b = d.createElement('button');
			b.type = 'button';
			b.textContent = txt;
			b.title = naslov;
			if (klasa) b.className = klasa;
			if (iskljuceno) b.disabled = true;
			b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); fn(); });
			return b;
		}

		L.forEach(function (sek, i) {
			var r = sek.getBoundingClientRect();
			var top = r.top + sy, left = r.left + sw;

			var okvir = d.createElement('div');
			okvir.className = 'itx-ui-okvir';
			okvir.setAttribute('data-itx-ui', 't');
			okvir.style.cssText = 'top:' + top + 'px;left:' + left + 'px;width:' + r.width + 'px;height:' + r.height + 'px;';
			sloj.appendChild(okvir);

			var alat = d.createElement('div');
			alat.className = 'itx-ui-alat';
			alat.setAttribute('data-itx-ui', 't');
			alat.style.cssText = 'top:' + (top + 8) + 'px;left:' + (left + r.width - 8) + 'px;transform:translateX(-100%);';
			alat.appendChild(dugme('↑', 'Pomeri gore', '', function () { self.moveSection(i, -1); }, i === 0));
			alat.appendChild(dugme('↓', 'Pomeri dole', '', function () { self.moveSection(i, 1); }, i === L.length - 1));
			alat.appendChild(dugme('⧉', 'Napravi kopiju ove sekcije', '', function () { self.duplicateSection(i); }));
			var slobodan = sek.querySelector('[data-itx-free]');
			if (slobodan) {
				alat.appendChild(dugme('🖼 Slika', 'Dodaj sliku u ovu sekciju', '', function () { self.addImageToBlock(slobodan); }));
			}
			alat.appendChild(dugme('✕', 'Obriši ovu sekciju', 'itx-x', function () {
				if (d.defaultView.confirm('Obrisati celu ovu sekciju?')) self.deleteSection(i);
			}));
			sloj.appendChild(alat);

			var plus = d.createElement('button');
			plus.type = 'button';
			plus.className = 'itx-ui-plus';
			plus.setAttribute('data-itx-ui', 't');
			plus.textContent = '+ Dodaj sekciju';
			plus.style.cssText = 'top:' + (top + r.height - 14) + 'px;left:' + (left + r.width / 2) + 'px;';
			plus.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); self.addSection(i); });
			sloj.appendChild(plus);
		});

		if (!L.length) {
			var prvi = d.createElement('button');
			prvi.type = 'button';
			prvi.className = 'itx-ui-plus';
			prvi.setAttribute('data-itx-ui', 't');
			prvi.textContent = '+ Dodaj prvu sekciju';
			prvi.style.cssText = 'top:40px;left:50%;';
			prvi.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); self.addSection(-1); });
			sloj.appendChild(prvi);
		}
	};
})(typeof window !== 'undefined' ? window : this);
