/**
 * ITX Content Editor — jezgro
 * ---------------------------------------------------------------
 * Radi nad živim DOM-om strane u iframe-u, ali izmene primenjuje
 * na "netaknuti šablon" (pristine template) parsiran iz sirovog
 * post_content-a. Time runtime izmene teme (reveal klase, slajder
 * stanja, transformi...) NIKAD ne završe u sačuvanom sadržaju.
 *
 * Uređivati se mogu SAMO: tekst (elementi sa čistim tekstom /
 * inline formatiranjem) i slike (zamena src-a). Struktura je
 * nedodirljiva.
 */
(function (global) {
	'use strict';

	var INLINE_OK = { BR: 1, STRONG: 1, EM: 1, B: 1, I: 1, U: 1, SMALL: 1, SUP: 1, SUB: 1, MARK: 1 };
	var TEXT_TAGS = { H1: 1, H2: 1, H3: 1, H4: 1, H5: 1, H6: 1, P: 1, LI: 1, SPAN: 1, A: 1, BUTTON: 1, LABEL: 1, ADDRESS: 1, FIGCAPTION: 1, TD: 1, TH: 1, DT: 1, DD: 1, BLOCKQUOTE: 1 };

	function allChildrenInline(el) {
		for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
			if (!INLINE_OK[c.tagName]) return false;
		}
		return true;
	}
	function hasText(el) {
		return /\S/.test(el.textContent || '');
	}

	function ItxEditor(opts) {
		this.doc = opts.doc;                       // document iframe-a
		this.live = opts.liveRoot;                 // <main> u živom DOM-u
		this.pristine = opts.pristineHTML;         // sirovi post_content
		this.onDirty = opts.onDirty || function () {};
		this.onImageRequest = opts.onImageRequest || null; // (imgEl, apply(url)) -> otvara medijateku

		var tdoc = this.doc.implementation.createHTMLDocument('t');
		tdoc.body.innerHTML = this.pristine;
		this.tmpl = tdoc.body;                     // netaknuti šablon (skripte se NE izvršavaju)

		this._structureOk = this._verifyStructure();
		this.dirtyEls = [];                        // {el, path} — celi editabilni elementi sa izmenom
		this.textSpans = [];                       // {span, parentPath, tmplIdx} — privremeni spanovi oko golih tekst čvorova
		this.imgEdits = 0;
		this._dirty = false;

		if (this._structureOk) {
			this._scan(this.live);
			this._installGuards();
		}
	}

	/* ---------- mapiranje živi DOM <-> šablon ---------- */

	// putanja elementa: indeksi među ELEMENT decom, od live root-a
	ItxEditor.prototype._elPath = function (el) {
		var p = [], n = el;
		while (n && n !== this.live) {
			var i = 0, s = n;
			// privremeni spanovi editora (data-itx-tmp) ne postoje u šablonu — ne smeju da pomere indeks
			while ((s = s.previousElementSibling)) { if (!s.hasAttribute('data-itx-tmp')) i++; }
			p.unshift(i);
			n = n.parentElement;
		}
		return n === this.live ? p : null;
	};
	ItxEditor.prototype._tmplByPath = function (p) {
		var n = this.tmpl;
		for (var i = 0; i < p.length; i++) {
			n = n.children[p[i]];
			if (!n) return null;
		}
		return n;
	};

	// offset childNodes indeksa: <main> ima whitespace čvorove oko sadržaja kojih u šablonu nema
	ItxEditor.prototype._rootOffset = function () {
		function firstElIdx(node) {
			var i = 0;
			for (var c = node.firstChild; c; c = c.nextSibling, i++) {
				if (c.nodeType === 1) return i;
			}
			return 0;
		}
		return firstElIdx(this.live) - firstElIdx(this.tmpl);
	};

	// provera 1:1 strukture (element po element) — uslov da editor sme da radi
	ItxEditor.prototype._verifyStructure = function () {
		function sig(root) {
			var out = [];
			(function walk(el) {
				for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
					out.push(c.tagName);
					walk(c);
				}
			})(root);
			return out.join(',');
		}
		return sig(this.live) === sig(this.tmpl);
	};

	/* ---------- skeniranje editabilnog ---------- */

	ItxEditor.prototype._scan = function (root) {
		var self = this;
		(function walk(el) {
			for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
				if (c.hasAttribute('data-itx-tmp')) continue;   // naši privremeni spanovi nisu deo strukture
				if (c.classList && c.classList.contains('itx-blok-sadrzaj')) {
					if (self.initFreeBlock) self.initFreeBlock(c);   // slobodan blok — uređuje se kao blog
					continue;
				}
				if (TEXT_TAGS[c.tagName] && allChildrenInline(c) && hasText(c)) {
					self._makeEditable(c);
				} else {
					self._wrapStrayText(c);
					walk(c);
				}
			}
		})(root);
	};

	ItxEditor.prototype._makeEditable = function (el) {
		var self = this;
		var path = this._elPath(el);
		if (!path || !this._tmplByPath(path)) return;
		el.setAttribute('contenteditable', 'true');
		el.setAttribute('data-itx-edit', 't');
		el.addEventListener('keydown', function (e) {
			if (e.key === 'Enter') e.preventDefault();       // bez novih pasusa/redova
		});
		el.addEventListener('paste', function (e) {          // paste = samo čist tekst
			e.preventDefault();
			var t = (e.clipboardData || self.doc.defaultView.clipboardData).getData('text/plain');
			self.doc.execCommand('insertText', false, t);
		});
		el.addEventListener('input', function () {
			if (self.dirtyEls.indexOf(el) === -1) self.dirtyEls.push(el);
			self._markDirty();
		});
	};

	// goli tekst čvorovi u "mešovitim" elementima (npr. tekst dugmeta pored SVG ikonice)
	ItxEditor.prototype._wrapStrayText = function (el) {
		var self = this;
		var parentPath = this._elPath(el);
		if (!parentPath || !this._tmplByPath(parentPath)) return;
		var off = el === this.live ? this._rootOffset() : 0;
		var snapshot = [];
		var idx = 0;
		for (var n = el.firstChild; n; n = n.nextSibling, idx++) {
			if (n.nodeType === 3 && /\S/.test(n.data)) {
				var m = n.data.match(/^(\s*)([\s\S]*?)(\s*)$/);
				snapshot.push({ node: n, idx: idx - off, lead: m[1], trail: m[3] });
			}
		}
		snapshot.forEach(function (rec) {
			var tparent = self._tmplByPath(parentPath);
			var tnode = tparent && tparent.childNodes[rec.idx];
			if (!tnode || tnode.nodeType !== 3) return;      // mapiranje nije sigurno -> preskoči
			var span = self.doc.createElement('span');
			span.setAttribute('data-itx-tmp', 't');
			span.setAttribute('contenteditable', 'true');
			rec.node.parentNode.insertBefore(span, rec.node);
			span.appendChild(rec.node);
			span.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });
			span.addEventListener('paste', function (e) {
				e.preventDefault();
				var t = (e.clipboardData || self.doc.defaultView.clipboardData).getData('text/plain');
				self.doc.execCommand('insertText', false, t);
			});
			span.addEventListener('input', function () { self._markDirty(); });
			self.textSpans.push({ span: span, parentPath: parentPath, tmplIdx: rec.idx, lead: rec.lead, trail: rec.trail });
		});
	};

	/* ---------- zaštita: bez navigacije, bez ponašanja teme ---------- */

	ItxEditor.prototype._installGuards = function () {
		var self = this;
		this.doc.addEventListener('click', function (e) {
			// naša sopstvena dugmad (overlay za sekcije) — pusti ih da rade
			if (e.target.closest && e.target.closest('[data-itx-ui]')) return;
			// naši dozvoljeni prekidači da bi skriveni tekst bio dostupan:
			var flip = e.target.closest && e.target.closest('.flip-hint');
			if (flip) {
				var card = flip.closest('[data-flip]');
				if (card) card.classList.toggle('is-flipped');
				e.preventDefault(); e.stopPropagation(); return;
			}
			var faq = e.target.closest && e.target.closest('.faq-q');
			if (faq) {
				var item = faq.closest('.faq-item');
				if (item) item.classList.toggle('is-open');
				e.preventDefault(); e.stopPropagation(); return;
			}
			// klik na sliku u sadržaju -> zamena kroz medijateku
			var img = e.target.tagName === 'IMG' ? e.target : null;
			if (img && self.live.contains(img) && self.onImageRequest) {
				e.preventDefault(); e.stopPropagation();
				self.onImageRequest(img, function (url) { self._applyImage(img, url); });
				return;
			}
			// linkovi/dugmad: bez navigacije i bez tema-ponašanja tokom uređivanja
			if (e.target.closest && (e.target.closest('a') || e.target.closest('button'))) {
				e.preventDefault();
			}
			e.stopPropagation();
		}, true);
		this.doc.addEventListener('submit', function (e) { e.preventDefault(); e.stopPropagation(); }, true);
	};

	ItxEditor.prototype._applyImage = function (img, url) {
		var path = this._elPath(img);
		var timg = path && this._tmplByPath(path);
		if (!timg || timg.tagName !== 'IMG') return;
		img.src = url;
		img.removeAttribute('srcset');
		timg.setAttribute('src', url);
		timg.removeAttribute('srcset');
		this.imgEdits++;
		this._markDirty();
	};

	ItxEditor.prototype._markDirty = function () {
		this._dirty = true;
		this.onDirty();
	};

	/* ---------- izlaz ---------- */

	// inline sanitizacija za innerHTML editabilnog elementa
	function sanitizeInline(doc, html) {
		var box = doc.createElement('div');
		box.innerHTML = html;
		(function walk(el) {
			var c = el.firstChild;
			while (c) {
				var next = c.nextSibling;
				if (c.nodeType === 1) {
					if (INLINE_OK[c.tagName]) {
						while (c.attributes.length) c.removeAttribute(c.attributes[0].name);
						walk(c);
					} else {
						// nedozvoljen tag -> zameni sopstvenim tekstom
						el.replaceChild(doc.createTextNode(c.textContent), c);
					}
				} else if (c.nodeType !== 3) {
					el.removeChild(c);
				}
				c = next;
			}
		})(box);
		return box.innerHTML;
	}

	// sanitizacija slobodnog bloka — dozvoljeni su blok tagovi kao u blogu
	var BLOCK_OK = { P:1, H2:1, H3:1, H4:1, UL:1, OL:1, LI:1, FIGURE:1, FIGCAPTION:1, IMG:1, BR:1, STRONG:1, EM:1, B:1, I:1, A:1 };
	var ATTR_OK  = { IMG:{src:1, alt:1}, A:{href:1} };
	function sanitizeBlock(doc, html) {
		var box = doc.createElement('div');
		box.innerHTML = html;
		(function walk(el) {
			var c = el.firstChild;
			while (c) {
				var next = c.nextSibling;
				if (c.nodeType === 1) {
					if (BLOCK_OK[c.tagName]) {
						var keep = ATTR_OK[c.tagName] || {};
						for (var i = c.attributes.length - 1; i >= 0; i--) {
							var a = c.attributes[i].name;
							if (!keep[a]) c.removeAttribute(a);
						}
						walk(c);
					} else {
						// nedozvoljen tag -> zameni sopstvenim tekstom
						el.replaceChild(doc.createTextNode(c.textContent), c);
					}
				} else if (c.nodeType !== 3) {
					el.removeChild(c);
				}
				c = next;
			}
		})(box);
		return box.innerHTML;
	}

	ItxEditor.prototype.isDirty = function () { return this._dirty; };
	ItxEditor.prototype.structureOk = function () { return this._structureOk; };

	ItxEditor.prototype.getContent = function () {
		if (!this._dirty) return this.pristine;              // bez izmena -> bajt-identično
		var self = this;
		this.dirtyEls.forEach(function (el) {
			var t = self._tmplByPath(self._elPath(el));
			if (t) t.innerHTML = sanitizeInline(self.doc, el.innerHTML);
		});
		this.textSpans.forEach(function (rec) {
			var pPath = self._elPath(rec.span.parentElement);
			var tparent = pPath && self._tmplByPath(pPath);
			var tnode = tparent && tparent.childNodes[rec.tmplIdx];
			if (tnode && tnode.nodeType === 3) {
				var txt = rec.span.textContent.replace(/^\s+|\s+$/g, '');
				tnode.data = rec.lead + txt + rec.trail;   // originalne beline ostaju
			}
		});
		(this.freeEls || []).forEach(function (box) {
			var t = self._tmplByPath(self._elPath(box));
			if (t) t.innerHTML = sanitizeBlock(self.doc, box.innerHTML);
		});
		return this.tmpl.innerHTML;
	};

	global.itxSanitizeBlock = function (doc, html) { return sanitizeBlock(doc, html); };

	global.ItxEditor = ItxEditor;
})(typeof window !== 'undefined' ? window : this);
