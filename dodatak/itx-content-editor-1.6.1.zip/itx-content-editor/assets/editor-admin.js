/* ITX Uređivanje sadržaja — admin "lepak": iframe + medijateka + snimanje */
(function () {
	'use strict';
	if (typeof ITX_CE === 'undefined' || !ITX_CE.postId) return;

	var frame = document.getElementById('itxFrame');
	var btnSave = document.getElementById('itxSave');
	var btnDiscard = document.getElementById('itxDiscard');
	var status = document.getElementById('itxStatus');
	var editor = null;
	var saving = false;

	function setStatus(msg, cls) {
		status.textContent = msg || '';
		status.className = 'itx-ce-status' + (cls ? ' ' + cls : '');
	}

	function fetchPristine(cb) {
		var fd = new FormData();
		fd.append('action', 'itx_ce_get');
		fd.append('post_id', ITX_CE.postId);
		fd.append('nonce', ITX_CE.nonce);
		fetch(ITX_CE.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function (r) { return r.json(); })
			.then(function (j) {
				if (j && j.success) cb(null, j.data.content);
				else cb((j && j.data) || 'Greška pri čitanju sadržaja.');
			})
			.catch(function () { cb('Greška u mreži.'); });
	}

	function openMedia(imgEl, apply) {
		var picker = wp.media({
			title: 'Izaberite sliku',
			button: { text: 'Upotrebi ovu sliku' },
			library: { type: 'image' },
			multiple: false
		});
		picker.on('select', function () {
			var att = picker.state().get('selection').first().toJSON();
			apply(att.url);
		});
		picker.open();
	}

	function initEditor() {
		var doc = frame.contentDocument;
		var main = doc && doc.querySelector('main');
		if (!main) { setStatus('Na strani nije pronađen <main> sa sadržajem.', 'err'); return; }

		// stilovi za nagoveštaje editabilnog
		var link = doc.createElement('link');
		link.rel = 'stylesheet';
		link.href = ITX_CE.iframeCss;
		doc.head.appendChild(link);

		fetchPristine(function (err, pristine) {
			if (err) { setStatus(err, 'err'); return; }
			editor = new ItxEditor({
				doc: doc,
				liveRoot: main,
				pristineHTML: pristine,
				onDirty: function () {
					btnSave.disabled = false;
					btnDiscard.disabled = false;
					setStatus('Imate nesačuvane izmene');
				},
				onImageRequest: openMedia
			});
			if (!editor.structureOk()) {
				setStatus('Struktura strane se ne poklapa sa sačuvanim sadržajem — uređivanje onemogućeno radi bezbednosti.', 'err');
				editor = null;
				return;
			}
			if (editor.enableSections) editor.enableSections();
			setStatus('Spremno za uređivanje — tekst i slike menjate klikom, sekcije premeštate strelicama');
		});
	}

	frame.addEventListener('load', initEditor);

	btnSave.addEventListener('click', function () {
		if (!editor || saving) return;
		saving = true;
		btnSave.disabled = true;
		setStatus('Snimanje…');
		var fd = new FormData();
		fd.append('action', 'itx_ce_save');
		fd.append('post_id', ITX_CE.postId);
		fd.append('nonce', ITX_CE.nonce);
		fd.append('content', editor.getContent());
		fetch(ITX_CE.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function (r) { return r.json(); })
			.then(function (j) {
				saving = false;
				if (j && j.success) {
					setStatus('Sačuvano ✓', 'ok');
					btnDiscard.disabled = true;
					frame.src = frame.src; // reload -> svež pristine
				} else {
					setStatus((j && j.data) || 'Greška pri snimanju.', 'err');
					btnSave.disabled = false;
				}
			})
			.catch(function () {
				saving = false;
				setStatus('Greška u mreži.', 'err');
				btnSave.disabled = false;
			});
	});

	btnDiscard.addEventListener('click', function () {
		if (editor && editor.isDirty() && !window.confirm('Odbaciti sve nesačuvane izmene?')) return;
		btnSave.disabled = true;
		btnDiscard.disabled = true;
		setStatus('');
		frame.src = frame.src;
	});

	window.addEventListener('beforeunload', function (e) {
		if (editor && editor.isDirty() && !saving) {
			e.preventDefault();
			e.returnValue = '';
		}
	});
})();
