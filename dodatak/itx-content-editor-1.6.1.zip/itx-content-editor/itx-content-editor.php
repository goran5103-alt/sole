<?php
/**
 * Plugin Name: ITX Uređivanje sadržaja
 * Description: Bezbedni vizuelni editor za ručno kođene strane — klijent menja SAMO tekst i slike u pravom dizajnu strane (sa CSS-om teme), bez mogućnosti da razbije kod. Ujedno isključuje opasni Visual tab za strane (blog postovi zadržavaju normalan vizuelni editor).
 * Version: 1.6.1
 * Author: IT Expert
 * Author URI: https://izradasajtovasajta.com
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ITX_CE_VER', '1.6.1' );
define( 'ITX_CE_URL', plugin_dir_url( __FILE__ ) );
define( 'ITX_CE_DIR', plugin_dir_path( __FILE__ ) );

/* ------------------------------------------------
   1) Osigurač: Visual (TinyMCE) tab isključen SAMO za STRANE.
      Strane su ručno kođene (složen HTML, SVG ikonice, prazni
      div-ovi za efekte) i vizuelni editor bi ih pokidao.

      Blog postovi NAMERNO zadržavaju normalan vizuelni editor —
      oni su običan sadržaj (tekst + slike između) koji se često
      objavljuje, pa nema razloga terati nekoga da kuca HTML.
------------------------------------------------ */
add_filter( 'user_can_richedit', function ( $ok ) {
	$post = get_post();
	if ( $post && 'page' === $post->post_type ) {
		return false;
	}
	return $ok;
} );

/* Dodatna zaštita sadržaja strana od WP filtera koji menjaju tekst */
add_action( 'wp', function () {
	if ( is_page() ) {
		remove_filter( 'the_content', 'convert_smilies' );
		remove_filter( 'the_content', 'capital_P_dangit', 11 );
	}
} );

/* ------------------------------------------------
   2) Ulazi u editor: red-akcija na listi strana
------------------------------------------------ */
add_filter( 'page_row_actions', function ( $actions, $post ) {
	if ( 'page' === $post->post_type && current_user_can( 'edit_post', $post->ID ) ) {
		$url = admin_url( 'edit.php?post_type=page&page=itx-editor&post=' . $post->ID );
		$actions['itx_edit'] = '<a href="' . esc_url( $url ) . '" style="color:#6C8C27;font-weight:600;">Uredi sadržaj</a>';
	}
	return $actions;
}, 10, 2 );

add_action( 'admin_menu', function () {
	add_submenu_page(
		'edit.php?post_type=page',
		'Uredi sadržaj',
		'Uredi sadržaj',
		'edit_pages',
		'itx-editor',
		'itx_ce_render_editor_page'
	);
} );

/* Vidljivo dugme u samom ekranu za uređivanje strane (iznad Objavi dugmeta) */
add_action( 'post_submitbox_misc_actions', function () {
	$post = get_post();
	if ( ! $post || 'page' !== $post->post_type ) {
		return;
	}
	$url = admin_url( 'edit.php?post_type=page&page=itx-editor&post=' . $post->ID );
	echo '<div class="misc-pub-section" style="text-align:center;">'
	   . '<a href="' . esc_url( $url ) . '" class="button button-primary button-large" style="width:100%;background:#6C8C27;border-color:#5b7620;">Uredi sadržaj (tekst i slike)</a>'
	   . '<p style="margin:8px 0 0;color:#646970;font-size:11px;line-height:1.5;">Bezbedno uređivanje teksta i slika u pravom izgledu strane.</p>'
	   . '</div>';
} );

/* Stavka u gornjoj traci dok se strana gleda na sajtu */
add_action( 'admin_bar_menu', function ( $bar ) {
	if ( is_admin() || ! is_page() ) {
		return;
	}
	$id = get_queried_object_id();
	if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	$bar->add_node( array(
		'id'    => 'itx-ce-edit',
		'title' => 'Uredi sadržaj',
		'href'  => admin_url( 'edit.php?post_type=page&page=itx-editor&post=' . $id ),
	) );
}, 90 );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( false === strpos( $hook, 'itx-editor' ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'itx-ce-admin', ITX_CE_URL . 'assets/editor-admin.css', array(), filemtime( ITX_CE_DIR . 'assets/editor-admin.css' ) );
	wp_enqueue_script( 'itx-ce-core', ITX_CE_URL . 'assets/editor-core.js', array(), filemtime( ITX_CE_DIR . 'assets/editor-core.js' ), true );
	wp_enqueue_script( 'itx-ce-sections', ITX_CE_URL . 'assets/editor-sections.js', array( 'itx-ce-core' ), filemtime( ITX_CE_DIR . 'assets/editor-sections.js' ), true );
	wp_enqueue_script( 'itx-ce-admin', ITX_CE_URL . 'assets/editor-admin.js', array( 'itx-ce-core', 'itx-ce-sections', 'jquery' ), filemtime( ITX_CE_DIR . 'assets/editor-admin.js' ), true );

	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	wp_localize_script( 'itx-ce-admin', 'ITX_CE', array(
		'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'itx_ce_' . $post_id ),
		'postId'   => $post_id,
		'pageUrl'  => $post_id ? get_permalink( $post_id ) : '',
		'listUrl'  => admin_url( 'edit.php?post_type=page' ),
		'iframeCss'=> ITX_CE_URL . 'assets/editor-iframe.css',
	) );
} );

/* ------------------------------------------------
   3) Ekran editora: toolbar + iframe sa PRAVOM stranom
------------------------------------------------ */
function itx_ce_render_editor_page() {
	$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;

	// bez ?post= parametra -> izbor strane
	if ( ! $post_id ) {
		$pages = get_pages( array( 'sort_column' => 'menu_order,post_title' ) );
		echo '<div class="wrap"><h1>Uredi sadržaj</h1><p>Izaberite stranu:</p><ul style="font-size:15px;line-height:2;">';
		foreach ( $pages as $p ) {
			$url = admin_url( 'edit.php?post_type=page&page=itx-editor&post=' . $p->ID );
			echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $p->post_title ) . '</a></li>';
		}
		echo '</ul></div>';
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_die( 'Nemate dozvolu za uređivanje ove strane.' );
	}
	$post = get_post( $post_id );
	?>
	<div class="itx-ce-app">
		<div class="itx-ce-bar">
			<div class="itx-ce-bar-left">
				<a class="itx-ce-back" href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>">&larr; Strane</a>
				<strong><?php echo esc_html( $post->post_title ); ?></strong>
				<span class="itx-ce-hint">Kliknite na tekst da ga izmenite &middot; kliknite na sliku da je zamenite</span>
			</div>
			<div class="itx-ce-bar-right">
				<span class="itx-ce-status" id="itxStatus"></span>
				<button class="button" id="itxDiscard" disabled>Odbaci izmene</button>
				<button class="button button-primary" id="itxSave" disabled>Sačuvaj</button>
			</div>
		</div>
		<iframe id="itxFrame" class="itx-ce-frame" src="<?php echo esc_url( get_permalink( $post_id ) ); ?>"></iframe>
	</div>
	<?php
}

/* ------------------------------------------------
   4) AJAX: čitanje sirovog sadržaja + snimanje
------------------------------------------------ */
add_action( 'wp_ajax_itx_ce_get', function () {
	$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	check_ajax_referer( 'itx_ce_' . $post_id, 'nonce' );
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( 'Nedovoljne dozvole.' );
	}
	$post = get_post( $post_id );
	if ( ! $post ) {
		wp_send_json_error( 'Strana ne postoji.' );
	}
	wp_send_json_success( array( 'content' => $post->post_content ) );
} );

add_action( 'wp_ajax_itx_ce_save', function () {
	$post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
	check_ajax_referer( 'itx_ce_' . $post_id, 'nonce' );
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		wp_send_json_error( 'Nedovoljne dozvole.' );
	}
	$content = isset( $_POST['content'] ) ? wp_unslash( $_POST['content'] ) : '';
	if ( '' === trim( $content ) ) {
		wp_send_json_error( 'Prazan sadržaj — snimanje odbijeno.' );
	}
	// wp_update_post automatski pravi reviziju (sigurnosna mreža)
	$result = wp_update_post( array(
		'ID'           => $post_id,
		'post_content' => $content,
	), true );
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( $result->get_error_message() );
	}
	wp_send_json_success( array( 'saved' => true ) );
} );
